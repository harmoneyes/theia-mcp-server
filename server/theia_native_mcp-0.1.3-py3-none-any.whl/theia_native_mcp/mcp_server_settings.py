"""McpServerSettings: loads the MCP server's settings from its settings file.

Settings file: JSON at the path given with ``--settings``::

    {"endpoints": [{"name": "...", "url": "https://127.0.0.1:17420/v1", "token": "...",
                    "certificate": "~/sdk_host/sdk_rpc_server_cert.pem"}],
     "local_sdk_endpoint": {"address": "127.0.0.1", "port": 17420, "port_step": 2000,
                            "port_attempts": 5,
                            "certificate": "~/.theia/rpc_tls/sdk_rpc_server_cert.pem"},
     "knowledgebase": {"default_max_length": 5000}}

Every key is optional; a missing key, or no settings file, gives the built-in default (no
endpoints). Each endpoint's token is its ``token``. The local SDK's token is the SDK's default
token, read from the file beside its certificate (``http_sse_client.read_sdk_rpc_default_token``).
An endpoint's ``certificate``, and the local SDK endpoint's, is the path of that SDK's RPC
certificate or a copy of it (``~`` expanded); without it, the default certificate path is used
(``http_sse_client.default_sdk_rpc_server_certificate_path``).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_KNOWLEDGEBASE_MAX_LENGTH = 5000
DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS = "127.0.0.1"
DEFAULT_LOCAL_SDK_ENDPOINT_PORT = 17420
DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP = 2000
DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS = 5


class McpSettingsFileNotFoundError(FileNotFoundError):
    """The settings file given with ``--settings`` does not exist."""


@dataclass(frozen=True)
class SdkEndpointSettings:
    name: str
    url: str
    token: str | None
    certificate_path: Path | None = None


@dataclass(frozen=True)
class LocalSdkEndpointSettings:
    """The SDK endpoint ``connect`` tries when given no endpoint; its candidate ports follow the
    SDK's own port rule (design reference: SDK config file)."""

    address: str = DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS
    port: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT
    port_step: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP
    port_attempts: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS
    certificate_path: Path | None = None


@dataclass(frozen=True)
class KnowledgebaseSettings:
    default_max_length: int = DEFAULT_KNOWLEDGEBASE_MAX_LENGTH


@dataclass(frozen=True)
class McpServerSettings:
    endpoints: list[SdkEndpointSettings] = field(default_factory=list)
    local_sdk_endpoint: LocalSdkEndpointSettings = field(default_factory=LocalSdkEndpointSettings)
    knowledgebase: KnowledgebaseSettings = field(default_factory=KnowledgebaseSettings)


def _read_settings_file(settings_path: str | Path | None) -> dict:
    if not settings_path:
        return {}
    # An MCP client's registration may pass the path unexpanded, so expand "~" here.
    settings_file = Path(settings_path).expanduser()
    if not settings_file.is_file():
        raise McpSettingsFileNotFoundError(f"no settings file at {settings_file}")
    # utf-8-sig also reads files saved with a UTF-8 byte-order mark (Windows PowerShell 5.1).
    return json.loads(settings_file.read_text(encoding="utf-8-sig"))


def _endpoint_from_file_entry(endpoint_entry: dict) -> SdkEndpointSettings:
    certificate = endpoint_entry.get("certificate")
    return SdkEndpointSettings(
        name=endpoint_entry["name"],
        url=endpoint_entry["url"],
        token=endpoint_entry.get("token") or None,
        certificate_path=Path(certificate).expanduser() if certificate else None,
    )


def _local_sdk_endpoint_from_file_entry(local_sdk_endpoint_entry: dict) -> LocalSdkEndpointSettings:
    certificate = local_sdk_endpoint_entry.get("certificate")
    return LocalSdkEndpointSettings(
        address=local_sdk_endpoint_entry.get("address", DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS),
        port=local_sdk_endpoint_entry.get("port", DEFAULT_LOCAL_SDK_ENDPOINT_PORT),
        port_step=local_sdk_endpoint_entry.get("port_step", DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP),
        port_attempts=local_sdk_endpoint_entry.get(
            "port_attempts", DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS
        ),
        certificate_path=Path(certificate).expanduser() if certificate else None,
    )


def load_mcp_server_settings(settings_path: str | Path | None = None) -> McpServerSettings:
    """The settings in the file at ``settings_path`` (``--settings``); the built-in defaults when
    it is None. A path given but missing raises ``McpSettingsFileNotFoundError``."""
    settings_file_contents = _read_settings_file(settings_path)

    endpoints = [
        _endpoint_from_file_entry(endpoint_entry)
        for endpoint_entry in settings_file_contents.get("endpoints", [])
    ]

    knowledgebase_entry = settings_file_contents.get("knowledgebase", {})
    knowledgebase = KnowledgebaseSettings(
        default_max_length=knowledgebase_entry.get(
            "default_max_length", DEFAULT_KNOWLEDGEBASE_MAX_LENGTH
        )
    )

    return McpServerSettings(
        endpoints=endpoints,
        local_sdk_endpoint=_local_sdk_endpoint_from_file_entry(
            settings_file_contents.get("local_sdk_endpoint", {})
        ),
        knowledgebase=knowledgebase,
    )
