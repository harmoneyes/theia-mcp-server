"""The MCP server's filter over buffered SDK events: an array of field selector strings.

This is not the SDK's subscribe filter (a CloudEvents SQL string, evaluated by the SDK); it only
selects among events already buffered by this server."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

Filter = list[str]


class SdkEventFilterError(ValueError):
    """The filter is not an array of well-formed field selector strings."""


@dataclass(frozen=True)
class _FieldCondition:
    field_name: str
    is_not_equals: bool
    value: str


def _parse_field_selector(field_selector: str) -> list[_FieldCondition]:
    # Kubernetes field selector: `field=value` / `field!=value`, comma-separated, all must match.
    # https://kubernetes.io/docs/concepts/overview/working-with-objects/field-selectors/
    if " " in field_selector:
        raise SdkEventFilterError(
            f"malformed field selector '{field_selector}': spaces are not allowed"
        )

    conditions: list[_FieldCondition] = []
    for condition_text in field_selector.split(","):
        equals_position = condition_text.find("=")
        if equals_position == -1:
            raise SdkEventFilterError(
                f"malformed field selector '{field_selector}': "
                f"condition '{condition_text}' has no operator"
            )

        is_not_equals = equals_position > 0 and condition_text[equals_position - 1] == "!"
        field_name_length = equals_position - 1 if is_not_equals else equals_position
        field_name = condition_text[:field_name_length]
        value = condition_text[equals_position + 1:]

        if not field_name:
            raise SdkEventFilterError(
                f"malformed field selector '{field_selector}': "
                f"condition '{condition_text}' has no field"
            )
        if "=" in value:
            raise SdkEventFilterError(
                f"unknown operator in field selector '{field_selector}': "
                "only = and != are supported"
            )
        conditions.append(_FieldCondition(field_name, is_not_equals, value))
    return conditions


def _parse_filter(event_filter: Filter | None) -> list[list[_FieldCondition]]:
    if event_filter is None:
        return []
    if not isinstance(event_filter, list) or not all(
        isinstance(field_selector, str) for field_selector in event_filter
    ):
        raise SdkEventFilterError("filter must be an array of field selector strings")
    return [_parse_field_selector(field_selector) for field_selector in event_filter]


def _payload_value_as_text(payload_value: Any) -> str:
    """A JSON string's content, otherwise the value as compact JSON writes it."""
    if isinstance(payload_value, str):
        return payload_value
    return json.dumps(payload_value, separators=(",", ":"), ensure_ascii=False)


def _condition_matches(condition: _FieldCondition, payload: Any) -> bool:
    if not isinstance(payload, dict) or condition.field_name not in payload:
        return False
    values_are_equal = _payload_value_as_text(payload[condition.field_name]) == condition.value
    return not values_are_equal if condition.is_not_equals else values_are_equal


def event_matches_filter(event: Any, event_filter: Filter | None) -> bool:
    """True if the event's payload matches any entry of the filter; no filter matches every event.

    Raises SdkEventFilterError if the filter is invalid.
    """
    field_selector_entries = _parse_filter(event_filter)
    if not field_selector_entries:
        return True
    return any(
        all(_condition_matches(condition, event.payload) for condition in field_selector_entry)
        for field_selector_entry in field_selector_entries
    )
