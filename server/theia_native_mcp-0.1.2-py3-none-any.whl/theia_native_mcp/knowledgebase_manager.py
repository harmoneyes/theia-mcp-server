"""KnowledgebaseManager: index and read the bundled Theia knowledgebase.

A knowledgebase bundle is one zip per Theia SDK version in ``bundled_knowledgebases/``,
named ``theia_knowledgebase_<version>.zip`` and holding ``manifest.json``, ``mkdocs.yml``
and a ``docs/`` folder of MkDocs Markdown pages. The MkDocs files are read directly;
MkDocs itself is not used.

Anchors are relative URLs: ``concepts/readiness.md`` (a page),
``concepts/readiness.md#report-windows`` (a heading section) and
``concepts/readiness.md#char=0,412`` (a text block). The empty anchor is the ``nav:`` tree.
"""

from __future__ import annotations

import html
import json
import logging
import posixpath
import re
import unicodedata
import zipfile
from collections.abc import MutableSet
from dataclasses import dataclass, field
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

DEFAULT_BUNDLED_KNOWLEDGEBASES_DIRECTORY = Path(__file__).parent / "bundled_knowledgebases"
DEFAULT_MAX_LENGTH = 5000
TEXT_BLOCK_PREVIEW_LENGTH = 30

_BUNDLE_FILE_NAME_PATTERN = re.compile(r"^theia_knowledgebase_(.+)\.zip$")
_ATX_HEADING_PATTERN = re.compile(r"^ {0,3}(#{1,6})(?:[ \t]+(.*?))?[ \t]*$")
_ATX_CLOSING_SEQUENCE_PATTERN = re.compile(r"(?:^|[ \t]+)#+[ \t]*$")
_FENCE_OPEN_PATTERN = re.compile(r"^ {0,3}(`{3,}|~{3,})")
# RFC 5147 fragment identifier, char scheme: https://www.rfc-editor.org/rfc/rfc5147.html
_CHAR_FRAGMENT_PATTERN = re.compile(r"^char=(\d+),(\d+)$")
_CODE_SPAN_PATTERN = re.compile(r"(`+)(.+?)\1")


# Heading anchor ids follow MkDocs, which uses the Python-Markdown toc extension defaults:
# https://python-markdown.github.io/extensions/toc/ (slugify, separator "-", unique ids
# with "_1", "_2" suffixes), applied to the heading's rendered text with tags stripped.
def _toc_slugify(value: str, separator: str = "-") -> str:
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^\w\s-]", "", value).strip().lower()
    return re.sub(r"[{}\s]+".format(separator), separator, value)


_TOC_ID_COUNT_PATTERN = re.compile(r"^(.*)_([0-9]+)$")


def _toc_unique_id(heading_id: str, used_ids: MutableSet[str]) -> str:
    while heading_id in used_ids or not heading_id:
        match = _TOC_ID_COUNT_PATTERN.match(heading_id)
        if match:
            heading_id = "%s_%d" % (match.group(1), int(match.group(2)) + 1)
        else:
            heading_id = "%s_%d" % (heading_id, 1)
    used_ids.add(heading_id)
    return heading_id


def _strip_inline_markup(text_outside_code: str) -> str:
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text_outside_code)
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("*", "")
    return re.sub(r"(?<!\w)_+|_+(?!\w)", "", text)


def _heading_rendered_text(heading_markdown: str) -> str:
    rendered_parts = []
    position = 0
    for code_span in _CODE_SPAN_PATTERN.finditer(heading_markdown):
        rendered_parts.append(_strip_inline_markup(heading_markdown[position:code_span.start()]))
        rendered_parts.append(code_span.group(2).strip())
        position = code_span.end()
    rendered_parts.append(_strip_inline_markup(heading_markdown[position:]))
    return html.unescape("".join(rendered_parts)).strip()


@dataclass
class _MarkdownHeading:
    level: int
    title: str
    anchor_id: str
    start: int
    end: int = 0


@dataclass
class _KnowledgebasePage:
    path: str
    text: str
    front_matter: dict
    headings: list[_MarkdownHeading]


@dataclass
class _NavEntry:
    title: str | None
    page_path: str | None = None
    children: list["_NavEntry"] = field(default_factory=list)


@dataclass
class _KnowledgebaseBundle:
    zip_path: Path
    product_version: str
    revision_timestamp: str


def _split_front_matter(file_text: str) -> tuple[dict, str]:
    lines = file_text.splitlines(keepends=True)
    if not lines or lines[0].rstrip() != "---":
        return {}, file_text
    for line_number in range(1, len(lines)):
        if lines[line_number].rstrip() in ("---", "..."):
            front_matter = yaml.safe_load("".join(lines[1:line_number])) or {}
            if not isinstance(front_matter, dict):
                front_matter = {}
            return front_matter, "".join(lines[line_number + 1:])
    return {}, file_text


def _find_headings(page_text: str) -> list[_MarkdownHeading]:
    headings: list[_MarkdownHeading] = []
    used_ids: set[str] = set()
    open_fence = None
    position = 0
    for line in page_text.splitlines(keepends=True):
        line_start = position
        position += len(line)
        stripped_line = line.rstrip("\r\n")
        fence_match = _FENCE_OPEN_PATTERN.match(stripped_line)
        if open_fence is not None:
            if fence_match and fence_match.group(1)[0] == open_fence[0] \
                    and len(fence_match.group(1)) >= len(open_fence) \
                    and not stripped_line[fence_match.end():].strip():
                open_fence = None
            continue
        if fence_match:
            open_fence = fence_match.group(1)
            continue
        heading_match = _ATX_HEADING_PATTERN.match(stripped_line)
        if not heading_match:
            continue
        heading_markdown = _ATX_CLOSING_SEQUENCE_PATTERN.sub("", heading_match.group(2) or "")
        title = _heading_rendered_text(heading_markdown)
        headings.append(_MarkdownHeading(
            level=len(heading_match.group(1)),
            title=title,
            anchor_id=_toc_unique_id(_toc_slugify(title), used_ids),
            start=line_start,
        ))
    for index, heading in enumerate(headings):
        heading.end = len(page_text)
        for later_heading in headings[index + 1:]:
            if later_heading.level <= heading.level:
                heading.end = later_heading.start
                break
    return headings


def _parse_nav_entries(nav_value) -> list[_NavEntry]:
    entries: list[_NavEntry] = []
    for item in nav_value or []:
        if isinstance(item, str):
            entries.append(_NavEntry(title=None, page_path=_normalize_page_path(item)))
        elif isinstance(item, dict):
            for title, value in item.items():
                if isinstance(value, str):
                    if "://" in value:
                        continue
                    entries.append(_NavEntry(title=str(title), page_path=_normalize_page_path(value)))
                elif isinstance(value, list):
                    entries.append(_NavEntry(title=str(title), children=_parse_nav_entries(value)))
    return entries


def _normalize_page_path(path: str) -> str:
    normalized = posixpath.normpath(path.strip().lstrip("/"))
    return "" if normalized == "." else normalized


class _KnowledgebaseYamlLoader(yaml.SafeLoader):
    """Safe loader that reads MkDocs tags such as ``!ENV`` as null instead of failing."""


_KnowledgebaseYamlLoader.add_multi_constructor("", lambda loader, tag_suffix, node: None)


def _version_sort_key(bundle: _KnowledgebaseBundle) -> tuple:
    numeric_parts = tuple(int(part) for part in re.findall(r"\d+", bundle.product_version))
    return numeric_parts, bundle.product_version, bundle.revision_timestamp


class _OpenedKnowledgebase:
    """One bundle's pages and nav, read from its zip."""

    def __init__(self, bundle: _KnowledgebaseBundle):
        self.bundle = bundle
        self._pages: dict[str, _KnowledgebasePage] = {}
        with zipfile.ZipFile(bundle.zip_path) as bundle_zip:
            mkdocs_config = yaml.load(
                bundle_zip.read("mkdocs.yml").decode("utf-8"), Loader=_KnowledgebaseYamlLoader
            ) or {}
            for member_name in bundle_zip.namelist():
                if member_name.startswith("docs/") and member_name.endswith(".md"):
                    page_path = member_name[len("docs/"):]
                    front_matter, page_text = _split_front_matter(
                        bundle_zip.read(member_name).decode("utf-8")
                    )
                    self._pages[page_path] = _KnowledgebasePage(
                        path=page_path,
                        text=page_text,
                        front_matter=front_matter,
                        headings=_find_headings(page_text),
                    )
        self.nav_entries = _parse_nav_entries(mkdocs_config.get("nav"))

    def find_page(self, page_path: str) -> _KnowledgebasePage | None:
        return self._pages.get(page_path)

    def page_title(self, page: _KnowledgebasePage, nav_title: str | None = None) -> str:
        # MkDocs title order: nav, front matter title, level 1 heading, file name.
        if nav_title:
            return nav_title
        if page.front_matter.get("title"):
            return str(page.front_matter["title"])
        for heading in page.headings:
            if heading.level == 1:
                return heading.title
        return posixpath.splitext(posixpath.basename(page.path))[0]

    def find_nav_section_of_index_page(self, page_path: str) -> list[_NavEntry] | None:
        def search(entries: list[_NavEntry]) -> list[_NavEntry] | None:
            for entry in entries:
                if entry.children:
                    if any(child.page_path == page_path for child in entry.children) \
                            and posixpath.basename(page_path) == "index.md":
                        return [child for child in entry.children if child.page_path != page_path]
                    found = search(entry.children)
                    if found is not None:
                        return found
            return None

        return search(self.nav_entries)


def _one_line_preview(text: str) -> str:
    return " ".join(text[:TEXT_BLOCK_PREVIEW_LENGTH].split())


class KnowledgebaseManager:
    """Index and read the knowledgebase bundled for a Theia SDK version."""

    def __init__(
        self,
        bundled_knowledgebases_directory: Path | str = DEFAULT_BUNDLED_KNOWLEDGEBASES_DIRECTORY,
        default_max_length: int = DEFAULT_MAX_LENGTH,
    ):
        self._default_max_length = default_max_length
        self._bundles = self._find_bundles(Path(bundled_knowledgebases_directory))
        self._opened_knowledgebases: dict[Path, _OpenedKnowledgebase] = {}
        self._check_for_knowledgebase_updates()

    def get_knowledgebase_index(self, anchor: str, version: str | None = None) -> str:
        knowledgebase, version_note = self._select_knowledgebase(version)
        page_path, fragment = self._split_anchor(anchor)
        if not page_path:
            if fragment:
                raise LookupError(f"knowledgebase anchor not found: {anchor}")
            index_lines = self._root_index_lines(knowledgebase)
        else:
            index_lines = self._page_index_lines(knowledgebase, anchor, page_path, fragment)
        if version_note:
            index_lines = [version_note, ""] + index_lines
        return "\n".join(index_lines) + "\n"

    def read_knowledgebase(
        self,
        anchor: str,
        start_index: int = 0,
        max_length: int | None = None,
        version: str | None = None,
    ) -> dict:
        knowledgebase, version_note = self._select_knowledgebase(version)
        page_path, fragment = self._split_anchor(anchor)
        page = knowledgebase.find_page(page_path)
        if page is None:
            raise LookupError(f"knowledgebase anchor not found: {anchor}")
        section_start, section_end = self._resolve_fragment(page, fragment, anchor)
        section_text = page.text[section_start:section_end]
        if max_length is None:
            max_length = self._default_max_length
        start_index = max(0, start_index)
        returned_text = section_text[start_index:start_index + max(0, max_length)]
        end_index = start_index + len(returned_text)
        truncated = end_index < len(section_text)
        return {
            "text": returned_text,
            "total_characters": len(section_text),
            "truncated": truncated,
            "next_start_index": end_index if truncated else None,
            "version_note": version_note,
        }

    @staticmethod
    def _find_bundles(directory: Path) -> list[_KnowledgebaseBundle]:
        bundles = []
        if not directory.is_dir():
            return bundles
        for zip_path in sorted(directory.iterdir()):
            if not _BUNDLE_FILE_NAME_PATTERN.match(zip_path.name):
                continue
            with zipfile.ZipFile(zip_path) as bundle_zip:
                manifest = json.loads(bundle_zip.read("manifest.json").decode("utf-8"))
            bundles.append(_KnowledgebaseBundle(
                zip_path=zip_path,
                product_version=str(manifest["product_version"]),
                revision_timestamp=str(manifest.get("revision_timestamp", "")),
            ))
        return bundles

    @staticmethod
    def _check_for_knowledgebase_updates() -> None:
        logger.info("knowledgebase version check/revision check not implemented")

    def _select_knowledgebase(self, version: str | None) -> tuple[_OpenedKnowledgebase, str | None]:
        if not self._bundles:
            raise LookupError("no knowledgebase is bundled")
        version_note = None
        matching_bundles = [bundle for bundle in self._bundles if bundle.product_version == version]
        if matching_bundles:
            bundle = max(matching_bundles, key=_version_sort_key)
        else:
            bundle = max(self._bundles, key=_version_sort_key)
            if version is not None:
                version_note = (
                    f"Version note: no knowledgebase is bundled for Theia SDK version {version}; "
                    f"this is the knowledgebase for the most recent bundled version, "
                    f"{bundle.product_version}."
                )
        if bundle.zip_path not in self._opened_knowledgebases:
            self._opened_knowledgebases[bundle.zip_path] = _OpenedKnowledgebase(bundle)
        return self._opened_knowledgebases[bundle.zip_path], version_note

    @staticmethod
    def _split_anchor(anchor: str) -> tuple[str, str]:
        path_part, _, fragment = (anchor or "").partition("#")
        return _normalize_page_path(path_part), fragment

    @staticmethod
    def _resolve_fragment(page: _KnowledgebasePage, fragment: str, anchor: str) -> tuple[int, int]:
        if not fragment:
            return 0, len(page.text)
        char_match = _CHAR_FRAGMENT_PATTERN.match(fragment)
        if char_match:
            start, end = int(char_match.group(1)), int(char_match.group(2))
            if start <= end <= len(page.text):
                return start, end
            raise LookupError(f"knowledgebase anchor not found: {anchor}")
        for heading in page.headings:
            if heading.anchor_id == fragment:
                return heading.start, heading.end
        raise LookupError(f"knowledgebase anchor not found: {anchor}")

    def _root_index_lines(self, knowledgebase: _OpenedKnowledgebase) -> list[str]:
        lines = [f"# Theia SDK {knowledgebase.bundle.product_version} knowledgebase", ""]
        lines += self._nav_entry_lines(knowledgebase, knowledgebase.nav_entries, depth=0)
        return lines

    def _nav_entry_lines(
        self, knowledgebase: _OpenedKnowledgebase, entries: list[_NavEntry], depth: int
    ) -> list[str]:
        lines = []
        indent = "  " * depth
        for entry in entries:
            if entry.children:
                lines.append(f"{indent}- {entry.title}")
                lines += self._nav_entry_lines(knowledgebase, entry.children, depth + 1)
                continue
            page = knowledgebase.find_page(entry.page_path)
            if page is None:
                continue
            title = knowledgebase.page_title(page, entry.title)
            description = page.front_matter.get("description")
            note = f"{description} ({len(page.text)} chars)" if description else f"{len(page.text)} chars"
            lines.append(f"{indent}- [{title}]({page.path}): {note}")
        return lines

    def _page_index_lines(
        self, knowledgebase: _OpenedKnowledgebase, anchor: str, page_path: str, fragment: str
    ) -> list[str]:
        page = knowledgebase.find_page(page_path)
        if page is None:
            raise LookupError(f"knowledgebase anchor not found: {anchor}")
        section_start, section_end = self._resolve_fragment(page, fragment, anchor)
        scope_heading = next(
            (heading for heading in page.headings
             if fragment and heading.anchor_id == fragment), None
        )
        if scope_heading is not None:
            title = scope_heading.title
            scope_level = scope_heading.level
            content_start = page.text.find("\n", scope_heading.start)
            content_start = section_end if content_start == -1 else min(content_start + 1, section_end)
        elif fragment:
            title = "text block"
            scope_level = 6
            content_start = section_start
        else:
            title = knowledgebase.page_title(page)
            level_one_headings = [heading for heading in page.headings if heading.level == 1]
            scope_level = 1 if len(level_one_headings) <= 1 else 0
            content_start = 0
            page_title_heading = level_one_headings[0] if len(level_one_headings) == 1 else None
            if page_title_heading and not page.text[:page_title_heading.start].strip():
                line_end = page.text.find("\n", page_title_heading.start)
                content_start = len(page.text) if line_end == -1 else line_end + 1

        headings_in_scope = [
            heading for heading in page.headings
            if section_start <= heading.start < section_end and heading.level > scope_level
        ]
        child_level = min((heading.level for heading in headings_in_scope), default=None)
        child_headings = [heading for heading in headings_in_scope if heading.level == child_level]

        lines = [f"# {title}", "", f"{section_end - section_start} chars", ""]
        text_block_end = child_headings[0].start if child_headings else section_end
        lines += self._text_block_lines(page, content_start, text_block_end)
        for heading in child_headings:
            lines.append(
                f"- [{heading.title}]({page.path}#{heading.anchor_id}): "
                f"{heading.end - heading.start} chars"
            )
        if not fragment:
            child_pages = knowledgebase.find_nav_section_of_index_page(page.path)
            if child_pages:
                lines += ["", "Child pages:", ""]
                lines += self._nav_entry_lines(knowledgebase, child_pages, depth=0)
        return lines

    @staticmethod
    def _text_block_lines(page: _KnowledgebasePage, block_start: int, block_end: int) -> list[str]:
        block_text = page.text[block_start:block_end]
        stripped_text = block_text.strip()
        if not stripped_text:
            return []
        start = block_start + (len(block_text) - len(block_text.lstrip()))
        end = start + len(stripped_text)
        preview = _one_line_preview(stripped_text)
        return [f'- [text block]({page.path}#char={start},{end}): "{preview}" {end - start} chars']
