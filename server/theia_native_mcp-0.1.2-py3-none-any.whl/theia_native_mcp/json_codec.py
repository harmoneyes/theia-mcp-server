"""JSON encoding and decoding for the MCP server, behind the JsonCodec interface."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any


class JsonCodecError(Exception):
    """Raised when a value cannot be encoded as JSON or a text is not valid JSON."""


class JsonCodec(ABC):
    """Encodes values to JSON text and decodes JSON text to values."""

    @abstractmethod
    def encode_json(self, value: Any) -> str:
        """Return the JSON text of ``value``; raise JsonCodecError if it has none."""

    @abstractmethod
    def decode_json(self, text: str) -> Any:
        """Return the value that the JSON ``text`` holds; raise JsonCodecError if it is invalid."""


def _reject_non_json_constant(constant_name: str) -> Any:
    raise ValueError(f"{constant_name} is not valid JSON")


class StandardLibraryJsonCodec(JsonCodec):
    """JsonCodec on Python's standard ``json`` module."""

    def encode_json(self, value: Any) -> str:
        try:
            return json.dumps(value, allow_nan=False)
        except (TypeError, ValueError) as encode_error:
            raise JsonCodecError(f"cannot encode value as JSON: {encode_error}") from encode_error

    def decode_json(self, text: str) -> Any:
        try:
            return json.loads(text, parse_constant=_reject_non_json_constant)
        except (TypeError, ValueError) as decode_error:
            raise JsonCodecError(f"invalid JSON text: {decode_error}") from decode_error
