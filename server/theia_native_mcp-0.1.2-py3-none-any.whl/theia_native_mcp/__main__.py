"""``python -m theia_native_mcp``: stdio by default; ``--http`` for Streamable HTTP."""

from __future__ import annotations

import argparse
from collections.abc import Sequence

from theia_native_mcp.mcp_server_entry_points import (
    DEFAULT_HTTP_HOST,
    DEFAULT_HTTP_PORT,
    McpHttpSecretNotSetError,
    run_mcp_server_over_http,
    run_mcp_server_over_stdio,
)


def _mcp_server_argument_parser() -> argparse.ArgumentParser:
    argument_parser = argparse.ArgumentParser(
        prog="theia-native-mcp",
        description="MCP server for the Theia SDK JSON-RPC control surface.",
    )
    argument_parser.add_argument(
        "--http", action="store_true", help="serve Streamable HTTP instead of stdio"
    )
    argument_parser.add_argument(
        "--host", default=DEFAULT_HTTP_HOST, help=f"HTTP bind address (default {DEFAULT_HTTP_HOST})"
    )
    argument_parser.add_argument(
        "--port", type=int, default=DEFAULT_HTTP_PORT, help=f"HTTP port (default {DEFAULT_HTTP_PORT})"
    )
    argument_parser.add_argument(
        "--allowed-origin",
        action="append",
        default=[],
        dest="allowed_origins",
        help="an Origin header value HTTP accepts; repeatable",
    )
    return argument_parser


def main(command_line_arguments: Sequence[str] | None = None) -> None:
    argument_parser = _mcp_server_argument_parser()
    arguments = argument_parser.parse_args(command_line_arguments)
    if not arguments.http:
        run_mcp_server_over_stdio()
        return
    try:
        run_mcp_server_over_http(arguments.host, arguments.port, arguments.allowed_origins)
    except McpHttpSecretNotSetError as secret_not_set:
        argument_parser.exit(2, f"{argument_parser.prog}: {secret_not_set}\n")


if __name__ == "__main__":
    main()
