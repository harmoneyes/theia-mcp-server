"""Starts the MCP server over stdio (the default) or Streamable HTTP.

Both transports share the same tools and components; each component gets its own settings
from ``McpServerSettings``. stdio is the default and Streamable HTTP is opt-in, modelled on
Microsoft Playwright MCP (https://github.com/microsoft/playwright-mcp).

Streamable HTTP, per the MCP spec
(https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http):
binds localhost by default and validates ``Origin``, through the MCP Python SDK's
``TransportSecuritySettings``. Every request is authenticated with the fixed-secret bearer
token check in ``mcp_http_authentication``. stdio has no HTTP authentication.
"""

from __future__ import annotations

import importlib.metadata
from collections.abc import Sequence

from mcp.server import MCPServer
from mcp.server.transport_security import TransportSecuritySettings

from theia_native_mcp.http_sse_client import HttpSseClient
from theia_native_mcp.json_codec import StandardLibraryJsonCodec
from theia_native_mcp.knowledgebase_manager import (
    DEFAULT_BUNDLED_KNOWLEDGEBASES_DIRECTORY,
    KnowledgebaseManager,
)
from theia_native_mcp.mcp_http_authentication import (
    FixedSecretTokenVerifier,
    fixed_secret_auth_settings,
)
from theia_native_mcp.mcp_server_settings import (
    HTTP_SECRET_ENVIRONMENT_VARIABLE,
    McpServerSettings,
    load_mcp_server_settings,
)
from theia_native_mcp.mcp_tool_definitions import MCP_AGENT_TEXT, McpToolDefinitions
from theia_native_mcp.rpc_connection_manager import RpcConnectionManager
from theia_native_mcp.sdk_event_buffer import SdkEventBuffer

MCP_SERVER_NAME = "theia_native_mcp"
DEFAULT_HTTP_HOST = "127.0.0.1"
DEFAULT_HTTP_PORT = 8765
STREAMABLE_HTTP_PATH = "/mcp"
LOOPBACK_ALLOWED_HOSTS = ["127.0.0.1:*", "localhost:*", "[::1]:*"]


class McpHttpSecretNotSetError(RuntimeError):
    """Streamable HTTP was requested but no bearer secret is configured."""


def _build_mcp_server(mcp_server_settings: McpServerSettings, **mcp_server_auth_arguments) -> MCPServer:
    sdk_event_buffer = SdkEventBuffer()
    rpc_connection_manager = RpcConnectionManager(
        HttpSseClient(),
        StandardLibraryJsonCodec(),
        sdk_event_buffer,
        configured_endpoints=mcp_server_settings.endpoints,
        local_sdk_endpoint=mcp_server_settings.local_sdk_endpoint,
        default_token=mcp_server_settings.default_token,
    )
    knowledgebase_manager = KnowledgebaseManager(
        bundled_knowledgebases_directory=DEFAULT_BUNDLED_KNOWLEDGEBASES_DIRECTORY,
        default_max_length=mcp_server_settings.knowledgebase.default_max_length,
    )
    mcp_server = MCPServer(
        MCP_SERVER_NAME,
        version=importlib.metadata.version(MCP_SERVER_NAME),
        instructions=MCP_AGENT_TEXT["server_instructions"],
        **mcp_server_auth_arguments,
    )
    McpToolDefinitions(rpc_connection_manager, sdk_event_buffer, knowledgebase_manager).register_mcp_tools(
        mcp_server
    )
    return mcp_server


def _transport_security_settings(host: str, allowed_origins: Sequence[str]) -> TransportSecuritySettings:
    """Host and Origin validation: the bound host (and loopback names), and the allowed origins.

    A request without an ``Origin`` header (a non-browser client) is not rejected for it.
    """
    allowed_hosts = [*LOOPBACK_ALLOWED_HOSTS]
    bound_host_pattern = f"[{host}]:*" if ":" in host else f"{host}:*"
    if bound_host_pattern not in allowed_hosts:
        allowed_hosts.append(bound_host_pattern)
    return TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=allowed_hosts,
        allowed_origins=list(allowed_origins),
    )


def _mcp_server_url(host: str, port: int) -> str:
    url_host = f"[{host}]" if ":" in host else host
    return f"http://{url_host}:{port}"


def run_mcp_server_over_stdio() -> None:
    mcp_server = _build_mcp_server(load_mcp_server_settings())
    mcp_server.run("stdio")


def run_mcp_server_over_http(
    host: str = DEFAULT_HTTP_HOST,
    port: int = DEFAULT_HTTP_PORT,
    allowed_origins: Sequence[str] = (),
) -> None:
    mcp_server_settings = load_mcp_server_settings()
    if not mcp_server_settings.http_secret:
        raise McpHttpSecretNotSetError(
            f"Streamable HTTP needs a bearer secret: set {HTTP_SECRET_ENVIRONMENT_VARIABLE}"
        )
    mcp_server = _build_mcp_server(
        mcp_server_settings,
        token_verifier=FixedSecretTokenVerifier(mcp_server_settings.http_secret),
        auth=fixed_secret_auth_settings(_mcp_server_url(host, port)),
    )
    mcp_server.run(
        "streamable-http",
        host=host,
        port=port,
        streamable_http_path=STREAMABLE_HTTP_PATH,
        transport_security=_transport_security_settings(host, allowed_origins),
    )
